package com.example.loginWithsession;
public class config5 {
    public static final String DATA_URL = "http://dataUrl/Pathfolder/";
    public static final String user="?user=";
    public static final String pass="&pass=";
    public static final String wpage="search.php";

    public static final String KEY_TITLE = "title";
    public static final String KEY_DATE = "date";
    public static final String KEY_DATA =  "data";
    public static final String KEY_ID =  "id";
    public static final String JSON_ARRAY = "result";
}
