package com.example.loginWithsession;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;


public class MainActivity extends AppCompatActivity {
    EditText user,pswd;
    Button btnlog;
    ListView listview;
    String id;
    private int count;
    SharedPreferences pref;
    Intent intent;
    String usr,pass;
    String disply;
    SharedPreferences prf;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        user = (EditText)findViewById(R.id.eduser);
        pswd = (EditText)findViewById(R.id.edpswd);
        btnlog = (Button)findViewById(R.id.btnlogin);
        listview = (ListView)findViewById(R.id.listView);
        pref = getSharedPreferences("user_details",MODE_PRIVATE);

        btnlog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                getData();

            }
        });
        
    }

    private void getData() {
       usr = user.getText().toString().trim();
        pass = pswd.getText().toString().trim();

        if (usr.equals("")) {
            Toast.makeText(this, "Please Enter Username", Toast.LENGTH_LONG).show();
            return;
        }
        else if (pass.equals("")) {
            Toast.makeText(this, "Please Enter Password", Toast.LENGTH_LONG).show();
            return;
        }

        String url = config5.DATA_URL + config5.wpage+config5.user+ user.getText().toString().trim() + config5.pass+ pswd.getText().toString().trim() ;
        StringRequest stringRequest = new StringRequest(url, new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {

                showJSON(response);
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(MainActivity.this, error.getMessage().toString(), Toast.LENGTH_LONG).show();
                    }
                });

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }
    private void showJSON(String response) {
        ArrayList<HashMap<String, String>> list = new ArrayList<HashMap<String, String>>();
        try {
            JSONObject jsonObject = new JSONObject(response);
            JSONArray result = jsonObject.getJSONArray(config5.JSON_ARRAY);

           count =result.length();

            for (int i = 0; i < result.length(); i++) {
                JSONObject jo = result.getJSONObject(i);
             id  = jo.getString(config5.KEY_ID);
                final HashMap<String, String> employees = new HashMap<>();

                employees.put(config5.KEY_ID, id);

                list.add(employees);

            }

           if (count > 0)
           {
//
               Toast.makeText(this,"Hello," + usr.toString(), Toast.LENGTH_LONG).show();
               SharedPreferences.Editor editor = pref.edit();
               editor.putString("username",usr);
               editor.putString("id",id);
               editor.commit();
               intent = new Intent(MainActivity.this,Dashboard.class);

               if(pref.contains("username") && pref.contains("id")){
                   startActivity(intent);
               }
               return;

           }else {
               Toast.makeText(this, "Invalid Entry", Toast.LENGTH_LONG).show();
               return;

           }



        } catch (JSONException e) {
            e.printStackTrace();
        }



    }

}
