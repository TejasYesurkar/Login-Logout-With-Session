package com.example.loginWithsession;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

public class Homepage extends AppCompatActivity {
    SharedPreferences prf;
    Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);


        TextView result = (TextView)findViewById(R.id.resultView);
        prf = getSharedPreferences("user_details",MODE_PRIVATE);
        intent = new Intent(Homepage.this,MainActivity.class);
        //Toast.makeText(getApplicationContext(),"Hello"+prf.getString("username",null),Toast.LENGTH_LONG);
        result.setText("Hello, "+prf.getString("username",null));
        result.setText("Your Id, "+prf.getString("id",null));
    }
}
